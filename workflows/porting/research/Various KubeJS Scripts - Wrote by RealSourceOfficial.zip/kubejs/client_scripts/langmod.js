/** Add language entries */
ClientEvents.lang('en_us', (e) => {
    // Effect / Radiation
    e.add("death.attack.radiation", "%1$s died in a horrible way");
    e.add("entity.minecraft.villager.fluix_researcher", "Fluix Researcher")
    e.add("entity.minecraft.villager.mechanic", "Mechanic")
    e.add("effect.tetra.mining_speed", "Mining Speed")
    e.add("effect.tetra.suspended", "Suspended")
    e.add("effect.tetra.stun", "Stunned")
    e.add("effect.tetra.bleeding", "Bleeding")
    e.add("fluid_type.createsweetsandtreets.applesyrup", "Apple Syrup")
    e.add("fluid_type.createchromaticreturn.refined_mixture", "Refined Mixture")
    e.add("fluid_type.createchromaticreturn.shadow_essence", "Shadow Essence")
    e.add("item.minecraft.tipped_arrow.effect.spectral", "Spectral Arrow (Unused)")
})