GameStageEvents.stageAdded(event => {
    event.player.sendData('updatestages')
})