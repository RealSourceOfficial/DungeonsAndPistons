/* ServerEvents.tags('item', event => {
    foreach(tag in tags)
}) */