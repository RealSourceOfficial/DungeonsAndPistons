ServerEvents.recipes(event => {
    // disable recipes
    event.remove([{ input: 'enderio:broken_spawner' }, { input: 'enderio:powered_spawner' }])
    event.remove(['create:cutting/compat/forbidden_arcanus/stripped_cherrywood', 
        'create:cutting/compat/forbidden_arcanus/cherrywood', 
        'create:cutting/compat/forbidden_arcanus/stripped_cherrywood_log', 
        'create:cutting/compat/forbidden_arcanus/cherrywood_log'])

    event.remove(['create:cutting/compat/forbidden_arcanus/stripped_mysterywood', 
        'create:cutting/compat/forbidden_arcanus/mysterywood', 
        'create:cutting/compat/forbidden_arcanus/stripped_mysterywood_log', 
        'create:cutting/compat/forbidden_arcanus/mysterywood_log'])

    event.remove(['create_confectionery:ruby_chocolate_recipe_6',
        'create_confectionery:black_chocolate_recipe_6',
        'create_confectionery:white_chocolate_recipe_6',
        'create_confectionery:chocolate_recipe_6'])

    event.remove({id: 'create:filling/chocolate_bagutte'})
    
    event.remove({id: 'createchromaticreturn:creative_filling_tank_recipe'})


    // fixing a few recipes because they aren't setup properly :kek:
    event.recipes.create.mixing('32x copper_ingot', ['quartz', '16x create:crushed_raw_copper']).heated().id('createchromaticreturn:copper_doubling')
    event.recipes.create.mixing('32x gold_ingot', ['quartz', '16x create:crushed_raw_gold']).heated().id('createchromaticreturn:gold_doubling')
    event.recipes.create.mixing('32x iron_ingot', ['quartz', '16x create:crushed_raw_iron']).heated().id('createchromaticreturn:iron_doubling')
    event.recipes.create.mixing('32x create:zinc_ingot', ['quartz', '16x create:crushed_raw_zinc']).heated().id('createchromaticreturn:zinc_doubling')
    event.recipes.create.mixing('64x copper_ingot', ['quartz', 'createchromaticreturn:fortunite_bar', '16x create:crushed_raw_copper']).superheated().id('createchromaticreturn:copper_fortunite')
    event.recipes.create.mixing('64x gold_ingot', ['quartz', 'createchromaticreturn:fortunite_bar', '16x create:crushed_raw_gold']).superheated().id('createchromaticreturn:gold_fortunite')
    event.recipes.create.mixing('64x iron_ingot', ['quartz', 'createchromaticreturn:fortunite_bar', '16x create:crushed_raw_iron']).superheated().id('createchromaticreturn:iron_fortunite')
    event.recipes.create.mixing('64x create:zinc_ingot', ['quartz', 'createchromaticreturn:fortunite_bar', '16x create:crushed_raw_zinc']).superheated().id('createchromaticreturn:zinc_fortunite')
    
    
    
    // To fix
    /*
[18:12:36] [WARN] Error parsing recipe create:filling/chocolate_bagutte[create:filling]:{type:"filling","ingredients":[{createsweetsandtreets:bagutte"},{"amount":250,"fluid":"create:chocolate"}],"results":[{createsweetsandtreets:chocolatebagutte"}]}: com.google.gson.JsonSyntaxException: Unknown item 'createsweetsandtreets:bagutte' 
    */
    })
