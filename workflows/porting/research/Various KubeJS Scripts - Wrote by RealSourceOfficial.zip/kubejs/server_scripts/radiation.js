PlayerEvents.tick(event => {
    let player = event.player

    if (player.ticksExisted % 20 != 0) return

    if ((player.headArmorItem == Item.of('pneumaticcraft:pneumatic_helmet', '{UpgradeCache:{radiation_shielding:1}}')
        && player.chestArmorItem == Item.of('pneumaticcraft:pneumatic_chestplate', '{UpgradeCache:{radiation_shielding:1}}') 
        && player.legsArmorItem == Item.of('pneumaticcraft:pneumatic_leggings', '{UpgradeCache:{radiation_shielding:1}}') 
        && player.feetArmorItem == Item.of('pneumaticcraft:pneumatic_boots', '{UpgradeCache:{radiation_shielding:1}}')) ||
        (player.headArmorItem == Item.of('mekanism:mekasuit_helmet', '{mekData:{modules:{"mekanism:radiation_shielding_unit":{}}}}')
        && player.chestArmorItem == Item.of('mekanism:mekasuit_bodyarmor', '{mekData:{modules:{"mekanism:radiation_shielding_unit":{}}}}')
        && player.legsArmorItem == Item.of('mekanism:mekasuit_pants', '{mekData:{modules:{"mekanism:radiation_shielding_unit":{}}}}')
        && player.feetArmorItem == Item.of('mekanism:mekasuit_boots', '{mekData:{modules:{"mekanism:radiation_shielding_unit":{}}}}'))) return

    let radioactiveBlockPos = BlockPos.findClosestMatch(player.block.pos, 3, 3, pos => event.level.getBlock(pos).hasTag("forge:radioactive"))

    radioactiveBlockPos.ifPresent(() => event.server.runCommand(`mek radiation add 1 ~ ~ ~` /* ${severity} */))

    if (player.inventory.find("forge:radioactive") > -1) event.server.runCommand(`mek radiation addEntity ${player.name} 1 `/* ${severity} */)
})