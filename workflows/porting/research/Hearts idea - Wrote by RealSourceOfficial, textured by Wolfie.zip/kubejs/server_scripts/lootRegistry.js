LootJS.modifiers((event) => {
    event
        .addLootTableModifier("minecraft:chests/nether_bridge")
        .randomChance(0.01)
        .addLoot("kubejs:captured_soul")

    event
        .addLootTypeModifier(LootType.ENTITY)
        .randomChance(0.01)
        .addLoot("kubejs:lost_soul")
})

