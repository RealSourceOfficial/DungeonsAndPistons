ServerEvents.recipes(event => {
    event.shaped(
        Item.of('kubejs:purified_captured_soul', 1),
        [   
            'ABA',
            'BCB',
            'ABA'
        ],
        {
            A: 'minecraft:gold_ingot',
            B: 'kubejs:captured_soul',
            C: 'minecraft:diamond'
        }
    )

    event.shaped(
        Item.of('kubejs:captured_soul', 1),
        [
            'ABA',
            'CDC',
            'ABA'
        ],
        {
            A: 'minecraft:echo_shard',
            B: 'butcher:blood_liquid_bucket',
            C: 'kubejs:lost_soul',
            D: 'minecraft:soul_sand'
        }
    )
})