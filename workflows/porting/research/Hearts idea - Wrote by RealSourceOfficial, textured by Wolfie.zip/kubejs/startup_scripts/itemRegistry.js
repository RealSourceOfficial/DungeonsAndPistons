StartupEvents.registry('item', e => {
    e.create('captured_soul')
        .tooltip("\u00A78Consume to gain \u00A7c1HP")
        .displayName("Captured Soul")
        .food(food => {
            food
                .hunger(0)
                .saturation(10)
                .effect('instant_health', 1, 1, 1)
                .alwaysEdible()
                .fastToEat()
                .eaten(ctx => {
                    ctx.entity.maxHealth += 1
                })
        })
    e.create('purified_captured_soul')
        .tooltip("\u00A78A higher-quality \u00A7bsoul \u00A78found only in the hardest of enemies...\u00A7r\n\u00A78or, the craft bench, if your rich enough.\n\n\u00A78Consume to gain \u00A7c5HP")
        .displayName("Purified Captured Soul")
        .glow(true)
        .food(food => {
            food
                .hunger(0)
                .saturation(10)
                .effect('instant_health', 1, 2, 1)
                .alwaysEdible()
                .fastToEat()
                .eaten(ctx => {
                    ctx.entity.maxHealth += 5
                })
        })
    e.create('lost_soul')
        .tooltip("\u00A78A lost \u00A7bsoul\u00A78... maybe it can be used for crafting?")
        .displayName("Lost Soul")
})