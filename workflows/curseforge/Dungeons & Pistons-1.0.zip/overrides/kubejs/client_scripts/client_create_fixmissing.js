JEIEvents.addItems(e => {
  e.add(Ingredient.of('@create').getItemIds().toArray());
})
