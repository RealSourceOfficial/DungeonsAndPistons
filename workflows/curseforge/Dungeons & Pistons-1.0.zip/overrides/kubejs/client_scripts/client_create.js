JEIEvents.hideItems(event => {
  event.hide('createaddition:electric_motor')
	event.hide('createaddition:alternator')
	event.hide('createaddition:connector')
	event.hide('createaddition:small_light_connector')
	event.hide('createaddition:large_connector')
	event.hide('createaddition:tesla_coil')
})